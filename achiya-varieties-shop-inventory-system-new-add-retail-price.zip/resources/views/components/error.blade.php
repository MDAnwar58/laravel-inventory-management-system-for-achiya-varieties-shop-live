@error($fieldName)
  <div class="text-danger" role="alert">
    <ul class="mb-0 ps-3">
      <li><strong>{{ $message }}</strong></li>
    </ul>
  </div>
@enderror