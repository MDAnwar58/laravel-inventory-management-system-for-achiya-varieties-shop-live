<div class="datatable-footer">
  <div class="showing-info" id="showingInfo">Showing <span id="page"></span> to <span id="per-page"></span> of <span
      id="total-page"></span> entries</div>
  <div class="pagination-wrapper">
    <nav>
      <ul id="pagination" class="pagination">

      </ul>
    </nav>
  </div>
</div>
