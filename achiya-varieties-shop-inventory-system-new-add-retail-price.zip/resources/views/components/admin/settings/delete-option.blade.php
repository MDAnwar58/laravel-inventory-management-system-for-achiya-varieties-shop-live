<div class="d-flex justify-content-between align-items-center px-4 pt-1">
    <h5 class="text-secondary fw-semibold">Delete Option <span id="option"></span></h5>
    <div class="form-check form-switch">
        <input class="form-check-input" type="checkbox" id="delete-option" role="switch">
    </div>
</div>
<hr>
