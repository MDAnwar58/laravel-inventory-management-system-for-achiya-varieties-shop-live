<div class="d-flex justify-content-between align-items-center px-4">
    <h5 class="text-secondary fw-semibold">Authentication <span id="is-auth-system-status"></span></h5>
    <div class="form-check form-switch">
        <input class="form-check-input" type="checkbox" name="is_auth_system" id="is-auth-system" role="switch">
    </div>
</div>
<hr>
