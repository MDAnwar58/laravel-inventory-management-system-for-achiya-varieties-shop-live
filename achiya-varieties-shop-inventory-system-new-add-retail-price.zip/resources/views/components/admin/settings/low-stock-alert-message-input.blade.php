<div class="d-flex justify-content-between align-items-center px-4 pt-1">
    <h5 class="text-secondary fw-semibold">Low Stock Alert Message</h5>

    <button type="button" class="btn btn-sm btn-outline-primary pb-1 pt-2 rounded-3" id="low-stock-msg-set-btn">
        <i class="fa-solid fa-pen-to-square fs-4"></i>
    </button>
</div>
<hr>
