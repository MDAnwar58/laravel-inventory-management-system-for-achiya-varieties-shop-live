<div class="low-stocks"></div>
