<div class="customer-table-footer d-flex flex-column justify-content-center align-items-center">
    <div class="showing-info text-center py-2" id="showingInfo">Showing
        <span id="customer-page"></span> to
        <span id="customer-per-page"></span> of
        <span id="customer-total-page"></span> entries
    </div>
    <div class="pagination-wrapper">
        <nav>
            <ul id="customer-pagination" class="pagination flex-wrap justify-content-center">

            </ul>
        </nav>
    </div>
</div>
