<div class="col-md-12 d-flex order-1 order-xxl-2">
    <div class="w-100">
        <div class="card flex-fill w-100">
            <div class="card-header">
                <h5 class="card-title mb-0">Monthly Sales Products</h5>
            </div>
            <div class="card-body d-flex w-100" style="margin-top: -0.7rem;">
                <div class="align-self-center chart chart-lg">
                    <canvas id="chartjs-dashboard-bar"></canvas>
                </div>
            </div>
        </div>
    </div>
</div>
