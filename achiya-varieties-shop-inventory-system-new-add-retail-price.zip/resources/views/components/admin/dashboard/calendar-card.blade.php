<div class="col-12 col-xxl-5 col-xl-4 col-md-5 col-sm-9 d-flex">
    <div class="w-100">
        <div class="card flex-fill">
            <div class="card-header">
                <h5 class="card-title mb-0">Calendar</h5>
            </div>
            <div class="card-body pt-0 d-flex" style="margin-top: -0.5rem;">
                <div class="align-self-center w-100">
                    <div class="chart">
                        <div id="datetimepicker-dashboard"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
