<div class="bg-white rounded-3 shadow-sm py-2 px-4 mb-3 d-flex justify-content-between align-items-end">
  <h1 class="h3 fw-semibold text-secondary-emphasis">{{ $title }} List</h1>
  <button type="button" id="reset-dt-btn" class="btn btn-light py-2 reset-data-t-btn"><i
      class="fa-solid fa-arrows-rotate fs-4"></i></button>
</div>
