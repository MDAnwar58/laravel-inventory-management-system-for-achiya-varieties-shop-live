<div class="d-flex justify-content-center">
    <a class="auth-logo" href="{{ route('welcome') }}">
        <img src="{{ asset('favicon_io2/android-chrome-512x512.png') }}" style="width: 50px;" alt="logo">
        <div>
            আছিয়া
            <div style="font-size: 12px; margin-top: -0.55rem;">ভ‍্যারাইটিস শপ</div>
        </div>
    </a>
</div>
