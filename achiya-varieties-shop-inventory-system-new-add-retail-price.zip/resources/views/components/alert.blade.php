<script>
  const msg = "{{ $msg }}";
  const status = "{{ $status }}";
  processNotify(msg, status);
</script>
