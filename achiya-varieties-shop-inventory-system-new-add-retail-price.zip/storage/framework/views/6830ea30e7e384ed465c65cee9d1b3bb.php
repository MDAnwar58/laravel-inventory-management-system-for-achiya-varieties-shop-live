<div class="low-stocks"></div>
<?php /**PATH D:\programming\laravel\achiya-varieties-shop-inventory-system-new-add-retail-price\resources\views/components/admin/low-stocks.blade.php ENDPATH**/ ?>