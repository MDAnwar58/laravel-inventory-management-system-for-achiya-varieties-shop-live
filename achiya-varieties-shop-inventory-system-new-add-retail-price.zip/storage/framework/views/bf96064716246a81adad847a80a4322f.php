<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
'landing_page' => null,
'custmers_count' => 0
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
'landing_page' => null,
'custmers_count' => 0
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<?php
    if (!function_exists('format_number_short')) {
        function format_number_short($number): string
        {
            if ($number >= 1000000) {
                return 'M+';
            } elseif ($number >= 1000) {
                return 'K+';
            }
            return '+';
        }
    }

?>
<section class="stats">
    <div class="container">
        <div class="row justify-content-center">
            

            <div class="col-lg-3 col-md-6 stat-item fade-in">
                <div class="stat-wrapper" data-target="<?php echo e($custmers_count); ?>">
                    <span class="stat-number">0</span><span class="static-stat"><?php echo e(format_number_short($custmers_count)); ?></span>
                </div>
                <h5>Customers</h5>
                <p>Businesses trust our platform</p>
            </div>

            

            <div class="col-lg-3 col-md-6 stat-item fade-in">
                <div class="stat-wrapper" data-target="<?php echo e($landing_page->support_hour ?? 0); ?>">
                    <span class="stat-number">0</span><span class="static-stat">/24</span>
                </div>
                <h5>Support</h5>
                <p>Always here to help you</p>
            </div>
        </div>
    </div>
</section>
<?php /**PATH D:\programming\laravel\achiya-varieties-shop-inventory-system-new-add-retail-price\resources\views/components/userend/welcome/stats.blade.php ENDPATH**/ ?>