<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
'totalOrdersCountAndMonthlySalesOrdersPercentUpAndDown' => null

]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
'totalOrdersCountAndMonthlySalesOrdersPercentUpAndDown' => null

]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<div class="card">
    <div class="card-body">
        <div class="row">
            <div class="col mt-0">
                <h5 class="card-title">Orders</h5>
            </div>

            <div class="col-auto">
                <div class="stat text-primary">
                    <i class="align-middle" data-feather="shopping-cart"></i>
                </div>
            </div>
        </div>
        <h1 class="mt-1 mb-3"><?php echo e($totalOrdersCountAndMonthlySalesOrdersPercentUpAndDown->sales_orders_count); ?></h1>
        <div class="mb-0">
            <span class="<?php echo e($totalOrdersCountAndMonthlySalesOrdersPercentUpAndDown->trend === 'flat'
            ? 'text-warning'
            : ($totalOrdersCountAndMonthlySalesOrdersPercentUpAndDown->trend === 'up'
                ? 'text-success'
                : 'text-danger')); ?>"><i class="mdi mdi-arrow-bottom-right"></i> <?php echo e($totalOrdersCountAndMonthlySalesOrdersPercentUpAndDown->percentage_change); ?>%</span>
            <span class="text-muted">Since last week</span>
        </div>
    </div>
</div>
<?php /**PATH D:\programming\laravel\achiya-varieties-shop-inventory-system-new-add-retail-price\resources\views/components/admin/dashboard/orders-card.blade.php ENDPATH**/ ?>