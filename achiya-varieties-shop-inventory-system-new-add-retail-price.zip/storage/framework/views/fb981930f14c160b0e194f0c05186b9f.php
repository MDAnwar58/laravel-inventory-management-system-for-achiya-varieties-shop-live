<nav id="sidebar" class="sidebar js-sidebar">
    <button type="button" class="btn sidebar-close-btn px-2">
        <i class="fa-solid fa-xmark"></i>
    </button>
    <div class="sidebar-content js-simplebar">
        <a class="sidebar-brand" href="<?php echo e(route('welcome')); ?>">
        <span class="align-middle">
            <?php if (isset($component)) { $__componentOriginalc7ec7fb76df1e782f63048a719004621 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc7ec7fb76df1e782f63048a719004621 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.logo','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.logo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc7ec7fb76df1e782f63048a719004621)): ?>
<?php $attributes = $__attributesOriginalc7ec7fb76df1e782f63048a719004621; ?>
<?php unset($__attributesOriginalc7ec7fb76df1e782f63048a719004621); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc7ec7fb76df1e782f63048a719004621)): ?>
<?php $component = $__componentOriginalc7ec7fb76df1e782f63048a719004621; ?>
<?php unset($__componentOriginalc7ec7fb76df1e782f63048a719004621); ?>
<?php endif; ?>
        </span>
        </a>

        <ul class="sidebar-nav" style="padding-bottom: 5rem !important;">
            <li class="sidebar-header">Pages</li>

            <li class="sidebar-item <?php echo e(Route::is('admin.dashboard') ? 'active' : ''); ?>">
                <a class="sidebar-link" href="<?php echo e(route('admin.dashboard')); ?>"><i class="align-middle" data-feather="sliders"></i> <span class="align-middle">Dashboard</span></a>
            </li>

            <?php if(in_array(auth()->user()->role, ['owner', 'admin', 'super_admin'])): ?>
            <li class="sidebar-item <?php echo e(Route::is('admin.user') || Route::is('admin.user.create') || Route::is('admin.user.show') || Route::is('admin.user.edit') ? 'active' : ''); ?>">
                <a class="sidebar-link" href="<?php echo e(route('admin.user')); ?>">
                    <i class="align-middle" data-feather="users"></i>
                    <span class="align-middle">User</span></a>
            </li>
            <?php endif; ?>

            <li class="sidebar-header">Inventory</li>

            <li class="sidebar-item <?php echo e(Route::is('admin.item.types') || Route::is('admin.item.type.create') || Route::is('admin.item.type.edit') ? 'active' : ''); ?>">
                <a class="sidebar-link" href="<?php echo e(route('admin.item.types')); ?>">
                    <i class="align-middle" data-feather="align-left"></i>
                    <span class="align-middle">Item Type</span></a>
            </li>

            <li class="sidebar-item <?php echo e(Route::is('admin.brands') || Route::is('admin.brand.create') || Route::is('admin.brand.edit') ? 'active' : ''); ?>">
                <a class="sidebar-link" href="<?php echo e(route('admin.brands')); ?>">
                    <i class="fa-solid fa-code-branch"></i>
                    <span class="align-middle">Brand</span>
                </a>
            </li>

            <li class="sidebar-item <?php echo e(Route::is('admin.categories') || Route::is('admin.category.create') || Route::is('admin.category.edit') ? 'active' : ''); ?>">
                <a class="sidebar-link" href="<?php echo e(route('admin.categories')); ?>">
                    <i class="fa-solid fa-list"></i>
                    <span class="align-middle">Category</span>
                </a>
            </li>

            <li class="sidebar-item <?php echo e(Route::is('admin.sub.categories') || Route::is('admin.sub.category.create') || Route::is('admin.sub.category.edit') ? 'active' : ''); ?>">
                <a class="sidebar-link" href="<?php echo e(route('admin.sub.categories')); ?>">
                    <i class="fa-solid fa-layer-group"></i>
                    <span class="align-middle">Sub Category</span></a>
            </li>

            <li class="sidebar-item <?php echo e(Route::is('admin.products') || Route::is('admin.product.create') || Route::is('admin.product.edit') || Route::is('admin.product.show') ? 'active' : ''); ?>">
                <a class="sidebar-link" href="<?php echo e(route('admin.products')); ?>">
                    <i class="fa-solid fa-box"></i>
                    <span class="align-middle">Products</span></a>
            </li>

            <li class="sidebar-header">Sales</li>

            <li class="sidebar-item <?php echo e(Route::is('admin.customers') || Route::is('admin.customer.create') || Route::is('admin.customer.edit') ? 'active' : ''); ?>">
                <a class="sidebar-link" href="<?php echo e(route('admin.customers')); ?>">
                    <i class="fa-solid fa-users"></i>
                    <span class="align-middle">Customers</span></a>
            </li>

            <li class="sidebar-item <?php echo e(Route::is('admin.sales.orders') || Route::is('admin.sales.order.invoice') || Route::is('admin.sales.order.create') || Route::is('admin.sales.order.edit') ? 'active' : ''); ?>">
                <a class="sidebar-link" href="<?php echo e(route('admin.sales.orders')); ?>">
                    <i class="fa-solid fa-cart-shopping"></i>
                    <span class="align-middle">Sales Orders</span></a>
            </li>

            <li class="sidebar-header">Reports</li>

            <li class="sidebar-item <?php echo e(Route::is('admin.reports') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('admin.reports')); ?>" class="sidebar-link">
                    <i class="align-middle" data-feather="bar-chart-2"></i>
                    <span class="align-middle">All Reports</span>
                </a>
            </li>
            <?php if(in_array(auth()->user()->role, ['owner', 'admin', 'super_admin'])): ?>
            <li class="sidebar-header">Website Manage</li>
            <li class="sidebar-item <?php echo e(Route::is('admin.printing.contents') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('admin.printing.contents')); ?>" class="sidebar-link">
                    <i class="fa-solid fa-text-width"></i>
                    <span class="align-middle">Printing Content</span>
                </a>
            </li>
            <li class="sidebar-item <?php echo e(Route::is('admin.landing.page') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('admin.landing.page')); ?>" class="sidebar-link">
                    <i class="fa-solid fa-pager"></i>
                    <span class="align-middle">Landing Page</span>
                </a>
            </li>
            <?php endif; ?>
        </ul>
    </div>
</nav>
<div class="sidebar-custom-overlay"></div>
<?php /**PATH D:\programming\laravel\achiya-varieties-shop-inventory-system-new-add-retail-price\resources\views/components/admin/sidebar.blade.php ENDPATH**/ ?>