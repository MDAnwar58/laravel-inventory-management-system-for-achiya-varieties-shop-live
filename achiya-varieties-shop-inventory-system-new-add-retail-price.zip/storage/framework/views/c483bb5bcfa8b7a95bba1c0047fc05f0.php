<?php $__env->startSection('title', '- Dashboard'); ?>

<?php $__env->startPush('style'); ?>
<style>
    .bdt {
        font-family: 'Noto Sans Bengali', sans-serif;
        margin-right: 0.1rem;
    }
    #chartjs-dashboard-pie {
        height: 400px;
        width: 400px;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<h1 class="h3 mb-3"><strong>Analytics</strong> Dashboard</h1>

<div class="row justify-content-center">
    <div class="col-md-12 d-flex">
        <div class="w-100">
            <div class="row">
                <div class="col-xxl-3 col-xl-4 col-lg-6 col-md-4 col-sm-6">
                    <?php if (isset($component)) { $__componentOriginal030b1be301011afe16b13ea777ded5f3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal030b1be301011afe16b13ea777ded5f3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.dashboard.sales-units-count-card','data' => ['salesOrderProductsUnitsCountAndPerchent' => $salesOrderProductsUnitsCountAndPerchent]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.dashboard.sales-units-count-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['salesOrderProductsUnitsCountAndPerchent' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($salesOrderProductsUnitsCountAndPerchent)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal030b1be301011afe16b13ea777ded5f3)): ?>
<?php $attributes = $__attributesOriginal030b1be301011afe16b13ea777ded5f3; ?>
<?php unset($__attributesOriginal030b1be301011afe16b13ea777ded5f3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal030b1be301011afe16b13ea777ded5f3)): ?>
<?php $component = $__componentOriginal030b1be301011afe16b13ea777ded5f3; ?>
<?php unset($__componentOriginal030b1be301011afe16b13ea777ded5f3); ?>
<?php endif; ?>
                    
                </div>

                <div class="col-xxl-3 col-xl-4 col-lg-6 col-md-4 col-sm-6">
                    <?php if (isset($component)) { $__componentOriginal167bb287d7895fa07f689def87f448ce = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal167bb287d7895fa07f689def87f448ce = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.dashboard.sales-weight-card','data' => ['salesOrderProductsWeightsCountAndPercent' => $salesOrderProductsWeightsCountAndPercent]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.dashboard.sales-weight-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['salesOrderProductsWeightsCountAndPercent' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($salesOrderProductsWeightsCountAndPercent)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal167bb287d7895fa07f689def87f448ce)): ?>
<?php $attributes = $__attributesOriginal167bb287d7895fa07f689def87f448ce; ?>
<?php unset($__attributesOriginal167bb287d7895fa07f689def87f448ce); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal167bb287d7895fa07f689def87f448ce)): ?>
<?php $component = $__componentOriginal167bb287d7895fa07f689def87f448ce; ?>
<?php unset($__componentOriginal167bb287d7895fa07f689def87f448ce); ?>
<?php endif; ?>
                </div>

                <div class="col-xxl-3 col-xl-4 col-lg-6 col-md-4 col-sm-6">
                    <?php if (isset($component)) { $__componentOriginal915ad42e0eb5d844c993cd89b511a4a6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal915ad42e0eb5d844c993cd89b511a4a6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.dashboard.sales-feets-card','data' => ['salesOrderProductsFootsCountAndPercent' => $salesOrderProductsFootsCountAndPercent]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.dashboard.sales-feets-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['salesOrderProductsFootsCountAndPercent' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($salesOrderProductsFootsCountAndPercent)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal915ad42e0eb5d844c993cd89b511a4a6)): ?>
<?php $attributes = $__attributesOriginal915ad42e0eb5d844c993cd89b511a4a6; ?>
<?php unset($__attributesOriginal915ad42e0eb5d844c993cd89b511a4a6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal915ad42e0eb5d844c993cd89b511a4a6)): ?>
<?php $component = $__componentOriginal915ad42e0eb5d844c993cd89b511a4a6; ?>
<?php unset($__componentOriginal915ad42e0eb5d844c993cd89b511a4a6); ?>
<?php endif; ?>
                </div>

                <div class="col-xxl-3 col-xl-4 col-lg-6 col-md-4 col-sm-6">
                    <?php if (isset($component)) { $__componentOriginal469c7d33c693bdafa5800edcb0acbdce = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal469c7d33c693bdafa5800edcb0acbdce = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.dashboard.sales-yard-card','data' => ['salesOrderProductsYardsCountAndPercent' => $salesOrderProductsYardsCountAndPercent]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.dashboard.sales-yard-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['salesOrderProductsYardsCountAndPercent' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($salesOrderProductsYardsCountAndPercent)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal469c7d33c693bdafa5800edcb0acbdce)): ?>
<?php $attributes = $__attributesOriginal469c7d33c693bdafa5800edcb0acbdce; ?>
<?php unset($__attributesOriginal469c7d33c693bdafa5800edcb0acbdce); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal469c7d33c693bdafa5800edcb0acbdce)): ?>
<?php $component = $__componentOriginal469c7d33c693bdafa5800edcb0acbdce; ?>
<?php unset($__componentOriginal469c7d33c693bdafa5800edcb0acbdce); ?>
<?php endif; ?>
                </div>

                <div class="col-xxl-3 col-xl-4 col-lg-6 col-md-4 col-sm-6">
                    <?php if (isset($component)) { $__componentOriginalf559b627bae6a1692c770f209d2cf1d6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf559b627bae6a1692c770f209d2cf1d6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.dashboard.sales-meter-card','data' => ['salesOrderProductsMetersCountAndPercent' => $salesOrderProductsMetersCountAndPercent]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.dashboard.sales-meter-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['salesOrderProductsMetersCountAndPercent' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($salesOrderProductsMetersCountAndPercent)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf559b627bae6a1692c770f209d2cf1d6)): ?>
<?php $attributes = $__attributesOriginalf559b627bae6a1692c770f209d2cf1d6; ?>
<?php unset($__attributesOriginalf559b627bae6a1692c770f209d2cf1d6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf559b627bae6a1692c770f209d2cf1d6)): ?>
<?php $component = $__componentOriginalf559b627bae6a1692c770f209d2cf1d6; ?>
<?php unset($__componentOriginalf559b627bae6a1692c770f209d2cf1d6); ?>
<?php endif; ?>
                </div>

                <div class="col-xxl-3 col-xl-4 col-lg-6 col-md-4 col-sm-6">
                    <?php if (isset($component)) { $__componentOriginal45767d67485cb5fbde711ae4ee3ed3f8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal45767d67485cb5fbde711ae4ee3ed3f8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.dashboard.orders-card','data' => ['totalOrdersCountAndMonthlySalesOrdersPercentUpAndDown' => $totalOrdersCountAndMonthlySalesOrdersPercentUpAndDown]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.dashboard.orders-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['totalOrdersCountAndMonthlySalesOrdersPercentUpAndDown' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($totalOrdersCountAndMonthlySalesOrdersPercentUpAndDown)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal45767d67485cb5fbde711ae4ee3ed3f8)): ?>
<?php $attributes = $__attributesOriginal45767d67485cb5fbde711ae4ee3ed3f8; ?>
<?php unset($__attributesOriginal45767d67485cb5fbde711ae4ee3ed3f8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal45767d67485cb5fbde711ae4ee3ed3f8)): ?>
<?php $component = $__componentOriginal45767d67485cb5fbde711ae4ee3ed3f8; ?>
<?php unset($__componentOriginal45767d67485cb5fbde711ae4ee3ed3f8); ?>
<?php endif; ?>
                </div>

                <div class="col-xxl-3 col-xl-4 col-lg-6 col-md-4 col-sm-6">
                    <?php if (isset($component)) { $__componentOriginal2b7583226dd71f278f23b23de0e8993e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2b7583226dd71f278f23b23de0e8993e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.dashboard.earnings-card','data' => ['totalSalesOrderEarningsAndMonthlyEarningsIncreaseAndDecreasePercent' => $totalSalesOrderEarningsAndMonthlyEarningsIncreaseAndDecreasePercent]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.dashboard.earnings-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['totalSalesOrderEarningsAndMonthlyEarningsIncreaseAndDecreasePercent' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($totalSalesOrderEarningsAndMonthlyEarningsIncreaseAndDecreasePercent)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2b7583226dd71f278f23b23de0e8993e)): ?>
<?php $attributes = $__attributesOriginal2b7583226dd71f278f23b23de0e8993e; ?>
<?php unset($__attributesOriginal2b7583226dd71f278f23b23de0e8993e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2b7583226dd71f278f23b23de0e8993e)): ?>
<?php $component = $__componentOriginal2b7583226dd71f278f23b23de0e8993e; ?>
<?php unset($__componentOriginal2b7583226dd71f278f23b23de0e8993e); ?>
<?php endif; ?>
                </div>

                <div class="col-xxl-3 col-xl-4 col-lg-6 col-md-4 col-sm-6">
                    <?php if (isset($component)) { $__componentOriginal6d44485a48a87824159b337beab6567d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6d44485a48a87824159b337beab6567d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.dashboard.customers-card','data' => ['totalCustomersCount' => $totalCustomersCount]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.dashboard.customers-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['totalCustomersCount' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($totalCustomersCount)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6d44485a48a87824159b337beab6567d)): ?>
<?php $attributes = $__attributesOriginal6d44485a48a87824159b337beab6567d; ?>
<?php unset($__attributesOriginal6d44485a48a87824159b337beab6567d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6d44485a48a87824159b337beab6567d)): ?>
<?php $component = $__componentOriginal6d44485a48a87824159b337beab6567d; ?>
<?php unset($__componentOriginal6d44485a48a87824159b337beab6567d); ?>
<?php endif; ?>
                </div>

                <div class="col-xxl-3 col-xl-4 col-lg-6 col-md-4 col-sm-6">
                    <?php if (isset($component)) { $__componentOriginal51b69dcc740048849b214925c4885c5d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal51b69dcc740048849b214925c4885c5d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.dashboard.total-value-of-products-on-store','data' => ['totalvalueOfProductsOnStore' => $totalvalueOfProductsOnStore]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.dashboard.total-value-of-products-on-store'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['totalvalueOfProductsOnStore' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($totalvalueOfProductsOnStore)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal51b69dcc740048849b214925c4885c5d)): ?>
<?php $attributes = $__attributesOriginal51b69dcc740048849b214925c4885c5d; ?>
<?php unset($__attributesOriginal51b69dcc740048849b214925c4885c5d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal51b69dcc740048849b214925c4885c5d)): ?>
<?php $component = $__componentOriginal51b69dcc740048849b214925c4885c5d; ?>
<?php unset($__componentOriginal51b69dcc740048849b214925c4885c5d); ?>
<?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <?php if (isset($component)) { $__componentOriginalbbcd3e69393a7643e0aa406411adfadf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbbcd3e69393a7643e0aa406411adfadf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.dashboard.calendar-card','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.dashboard.calendar-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbbcd3e69393a7643e0aa406411adfadf)): ?>
<?php $attributes = $__attributesOriginalbbcd3e69393a7643e0aa406411adfadf; ?>
<?php unset($__attributesOriginalbbcd3e69393a7643e0aa406411adfadf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbbcd3e69393a7643e0aa406411adfadf)): ?>
<?php $component = $__componentOriginalbbcd3e69393a7643e0aa406411adfadf; ?>
<?php unset($__componentOriginalbbcd3e69393a7643e0aa406411adfadf); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginalffa006535c0cc0c70205dfd5db6b908d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalffa006535c0cc0c70205dfd5db6b908d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.dashboard.monthly-sales','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.dashboard.monthly-sales'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalffa006535c0cc0c70205dfd5db6b908d)): ?>
<?php $attributes = $__attributesOriginalffa006535c0cc0c70205dfd5db6b908d; ?>
<?php unset($__attributesOriginalffa006535c0cc0c70205dfd5db6b908d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalffa006535c0cc0c70205dfd5db6b908d)): ?>
<?php $component = $__componentOriginalffa006535c0cc0c70205dfd5db6b908d; ?>
<?php unset($__componentOriginalffa006535c0cc0c70205dfd5db6b908d); ?>
<?php endif; ?>
</div>

<div class="row justify-content-center">
    <?php if (isset($component)) { $__componentOriginale5c969476e86acec71940c28c9b93535 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale5c969476e86acec71940c28c9b93535 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.dashboard.monthly-sales-products-card','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.dashboard.monthly-sales-products-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale5c969476e86acec71940c28c9b93535)): ?>
<?php $attributes = $__attributesOriginale5c969476e86acec71940c28c9b93535; ?>
<?php unset($__attributesOriginale5c969476e86acec71940c28c9b93535); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale5c969476e86acec71940c28c9b93535)): ?>
<?php $component = $__componentOriginale5c969476e86acec71940c28c9b93535; ?>
<?php unset($__componentOriginale5c969476e86acec71940c28c9b93535); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal7e92235e42d42139c6126ea0c5938b09 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7e92235e42d42139c6126ea0c5938b09 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.dashboard.top-5-products-sales-count','data' => ['salesTop5ProductsCount' => $salesTop5ProductsCount]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.dashboard.top-5-products-sales-count'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['salesTop5ProductsCount' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($salesTop5ProductsCount)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7e92235e42d42139c6126ea0c5938b09)): ?>
<?php $attributes = $__attributesOriginal7e92235e42d42139c6126ea0c5938b09; ?>
<?php unset($__attributesOriginal7e92235e42d42139c6126ea0c5938b09); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7e92235e42d42139c6126ea0c5938b09)): ?>
<?php $component = $__componentOriginal7e92235e42d42139c6126ea0c5938b09; ?>
<?php unset($__componentOriginal7e92235e42d42139c6126ea0c5938b09); ?>
<?php endif; ?>
</div>

<div class="row">
<?php if (isset($component)) { $__componentOriginal007f3de3bf4b945075370fc3bbe9e733 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal007f3de3bf4b945075370fc3bbe9e733 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.dashboard.current-week-sales-earnings-and-products-card','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.dashboard.current-week-sales-earnings-and-products-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal007f3de3bf4b945075370fc3bbe9e733)): ?>
<?php $attributes = $__attributesOriginal007f3de3bf4b945075370fc3bbe9e733; ?>
<?php unset($__attributesOriginal007f3de3bf4b945075370fc3bbe9e733); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal007f3de3bf4b945075370fc3bbe9e733)): ?>
<?php $component = $__componentOriginal007f3de3bf4b945075370fc3bbe9e733; ?>
<?php unset($__componentOriginal007f3de3bf4b945075370fc3bbe9e733); ?>
<?php endif; ?>
</div>

<div class="row">
    <?php if (isset($component)) { $__componentOriginalb282085c63382f48dff0ad97fb864de8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb282085c63382f48dff0ad97fb864de8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.dashboard.recent-sales-orders','data' => ['latestOrders' => $latest_orders]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.dashboard.recent-sales-orders'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['latest_orders' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($latest_orders)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb282085c63382f48dff0ad97fb864de8)): ?>
<?php $attributes = $__attributesOriginalb282085c63382f48dff0ad97fb864de8; ?>
<?php unset($__attributesOriginalb282085c63382f48dff0ad97fb864de8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb282085c63382f48dff0ad97fb864de8)): ?>
<?php $component = $__componentOriginalb282085c63382f48dff0ad97fb864de8; ?>
<?php unset($__componentOriginalb282085c63382f48dff0ad97fb864de8); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginal13ffa7ef70bc656a842590b2084d60e4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal13ffa7ef70bc656a842590b2084d60e4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.dashboard.alert-for-products-stock-low-table','data' => ['lowStockProducts' => $low_stock_products]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.dashboard.alert-for-products-stock-low-table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['low_stock_products' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($low_stock_products)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal13ffa7ef70bc656a842590b2084d60e4)): ?>
<?php $attributes = $__attributesOriginal13ffa7ef70bc656a842590b2084d60e4; ?>
<?php unset($__attributesOriginal13ffa7ef70bc656a842590b2084d60e4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal13ffa7ef70bc656a842590b2084d60e4)): ?>
<?php $component = $__componentOriginal13ffa7ef70bc656a842590b2084d60e4; ?>
<?php unset($__componentOriginal13ffa7ef70bc656a842590b2084d60e4); ?>
<?php endif; ?>
</div>



<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<?php if(Session::has('status')): ?>
    <?php if (isset($component)) { $__componentOriginal5194778a3a7b899dcee5619d0610f5cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert','data' => ['msg' => Session::get('msg'),'status' => Session::get('status')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['msg' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(Session::get('msg')),'status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(Session::get('status'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $attributes = $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $component = $__componentOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginalc8b693f4f1fc529852e4ad6811029de1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc8b693f4f1fc529852e4ad6811029de1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.scripts','data' => ['getMonthlySalesOrderEarnings' => $getMonthlySalesOrderEarnings,'monthlySalesOrderProductsCount' => $monthlySalesOrderProductsCount,'salesTop5ProductsCount' => $salesTop5ProductsCount,'currentWeekSalesEarningsAndProductsCount' => $currentWeekSalesEarningsAndProductsCount]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.scripts'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['getMonthlySalesOrderEarnings' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($getMonthlySalesOrderEarnings),'monthlySalesOrderProductsCount' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($monthlySalesOrderProductsCount),'salesTop5ProductsCount' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($salesTop5ProductsCount),'currentWeekSalesEarningsAndProductsCount' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($currentWeekSalesEarningsAndProductsCount)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc8b693f4f1fc529852e4ad6811029de1)): ?>
<?php $attributes = $__attributesOriginalc8b693f4f1fc529852e4ad6811029de1; ?>
<?php unset($__attributesOriginalc8b693f4f1fc529852e4ad6811029de1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc8b693f4f1fc529852e4ad6811029de1)): ?>
<?php $component = $__componentOriginalc8b693f4f1fc529852e4ad6811029de1; ?>
<?php unset($__componentOriginalc8b693f4f1fc529852e4ad6811029de1); ?>
<?php endif; ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin-layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\programming\laravel\achiya-varieties-shop-inventory-system-new-add-retail-price\resources\views/pages/admin/dashboard.blade.php ENDPATH**/ ?>