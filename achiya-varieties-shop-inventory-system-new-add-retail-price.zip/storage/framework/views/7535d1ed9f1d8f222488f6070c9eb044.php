<?php $__env->startSection('content'); ?>
<?php if (isset($component)) { $__componentOriginalab38274b096a163ae8a0a747e64c0866 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalab38274b096a163ae8a0a747e64c0866 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.userend.hero-section','data' => ['landingPage' => $landing_page]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('userend.hero-section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['landing_page' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($landing_page)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalab38274b096a163ae8a0a747e64c0866)): ?>
<?php $attributes = $__attributesOriginalab38274b096a163ae8a0a747e64c0866; ?>
<?php unset($__attributesOriginalab38274b096a163ae8a0a747e64c0866); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalab38274b096a163ae8a0a747e64c0866)): ?>
<?php $component = $__componentOriginalab38274b096a163ae8a0a747e64c0866; ?>
<?php unset($__componentOriginalab38274b096a163ae8a0a747e64c0866); ?>
<?php endif; ?>

<?php if (isset($component)) { $__componentOriginal9e41b6838524d5e6cc53bf055ff94f7c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9e41b6838524d5e6cc53bf055ff94f7c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.userend.welcome.features','data' => ['landingPage' => $landing_page,'features' => $features]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('userend.welcome.features'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['landing_page' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($landing_page),'features' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($features)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9e41b6838524d5e6cc53bf055ff94f7c)): ?>
<?php $attributes = $__attributesOriginal9e41b6838524d5e6cc53bf055ff94f7c; ?>
<?php unset($__attributesOriginal9e41b6838524d5e6cc53bf055ff94f7c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9e41b6838524d5e6cc53bf055ff94f7c)): ?>
<?php $component = $__componentOriginal9e41b6838524d5e6cc53bf055ff94f7c; ?>
<?php unset($__componentOriginal9e41b6838524d5e6cc53bf055ff94f7c); ?>
<?php endif; ?>

<?php if (isset($component)) { $__componentOriginal68f2287247797c79e4644b3263837500 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal68f2287247797c79e4644b3263837500 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.userend.welcome.stats','data' => ['landingPage' => $landing_page,'custmersCount' => $custmers_count]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('userend.welcome.stats'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['landing_page' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($landing_page),'custmers_count' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($custmers_count)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal68f2287247797c79e4644b3263837500)): ?>
<?php $attributes = $__attributesOriginal68f2287247797c79e4644b3263837500; ?>
<?php unset($__attributesOriginal68f2287247797c79e4644b3263837500); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal68f2287247797c79e4644b3263837500)): ?>
<?php $component = $__componentOriginal68f2287247797c79e4644b3263837500; ?>
<?php unset($__componentOriginal68f2287247797c79e4644b3263837500); ?>
<?php endif; ?>

<?php if (isset($component)) { $__componentOriginalf84ad95125c82f72e2392ddfab8c75cc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf84ad95125c82f72e2392ddfab8c75cc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.userend.welcome.contact','data' => ['landingPage' => $landing_page,'contactInfos' => $contactInfos]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('userend.welcome.contact'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['landing_page' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($landing_page),'contactInfos' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($contactInfos)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf84ad95125c82f72e2392ddfab8c75cc)): ?>
<?php $attributes = $__attributesOriginalf84ad95125c82f72e2392ddfab8c75cc; ?>
<?php unset($__attributesOriginalf84ad95125c82f72e2392ddfab8c75cc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf84ad95125c82f72e2392ddfab8c75cc)): ?>
<?php $component = $__componentOriginalf84ad95125c82f72e2392ddfab8c75cc; ?>
<?php unset($__componentOriginalf84ad95125c82f72e2392ddfab8c75cc); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\programming\laravel\achiya-varieties-shop-inventory-system-new-add-retail-price\resources\views/welcome.blade.php ENDPATH**/ ?>