<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
'latest_orders' => []
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
'latest_orders' => []
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<div class="col-12 col-lg-12 d-flex">
    <div class="card flex-fill">
        <div class="card-header px-3 pb-0 d-flex justify-content-between align-items-center">
            <h5 class="card-title mb-0">Latest Orders</h5>
            <a href="<?php echo e(route('admin.sales.orders')); ?>" class="btn btn-sm btn-light border shadow rounded-3 fw-medium fs-5">Show All</a>
        </div>
        <div class="table-responsive">
            <table class="table table-hover my-0">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Order Date</th>
                        <th>Due Date</th>
                        <th>Payment Status</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $latest_orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <div style="width: 150px;">
                                <?php echo e($order->customer->name); ?>

                            </div>
                        </td>
                        <td>
                            <div style="width: 90px;"><?php echo e(date('d/m/Y', strtotime($order->order_date))); ?></div>
                        </td>
                        <td>
                            <div style="width: 90px;"><?php echo e($order->due_date ? date('d/m/Y', strtotime($order->due_date)) : 'N/A'); ?></div>
                        </td>
                        <td>
                            <div style="width: 110px;">
                                <?php if($order->payment_status === "paid"): ?>
                                <span class="badge bg-success-subtle text-success">Paid</span>
                                <?php elseif($order->payment_status === "due"): ?>
                                <span class="badge bg-warning-subtle text-warning">Due</span>
                                <?php elseif($order->payment_status === "partial due"): ?>
                                <span class="badge bg-info-subtle text-info">Partial Due</span>
                                <?php else: ?>
                                <span class="badge bg-danger-subtle text-danger">Cancel</span>
                                <?php endif; ?>
                            </div>
                        </td>
                        <td>
                            <?php if($order->status === "confirmed"): ?>
                            <span class="badge bg-success">Confirmed</span>
                            <?php else: ?>
                            <span class="badge bg-danger">Cancelled</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <a href="<?php echo e(route('admin.sales.order.invoice', $order->id)); ?>" class="btn btn-sm btn-outline-info">

                                <i class="fa-solid fa-eye"></i>
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php /**PATH D:\programming\laravel\achiya-varieties-shop-inventory-system-new-add-retail-price\resources\views/components/admin/dashboard/recent-sales-orders.blade.php ENDPATH**/ ?>