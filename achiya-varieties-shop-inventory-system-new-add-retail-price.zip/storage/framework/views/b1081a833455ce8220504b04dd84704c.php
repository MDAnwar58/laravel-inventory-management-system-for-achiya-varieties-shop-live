<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'proucts_count_by_items' => [],
    'proucts_count_by_brands' => [],
    'proucts_count_by_categories' => [],
    'proucts_count_by_sub_categories' => [],
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'proucts_count_by_items' => [],
    'proucts_count_by_brands' => [],
    'proucts_count_by_categories' => [],
    'proucts_count_by_sub_categories' => [],
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<script>
document.addEventListener("DOMContentLoaded", function() {
    // Demo data: categories with product counts
    const itemTypeWiseArea = document.querySelector('.item-type-wise-area');
    var itemsByProductCounts = <?php echo json_encode($proucts_count_by_items, 15, 512) ?>;
    if (itemsByProductCounts.length > 0)itemTypeWiseArea.classList.remove('d-none');
    // Prepare arrays for chart
    let itemTypes = itemsByProductCounts.map(item => item.name);
    let counts = itemsByProductCounts.map(item => item.products_count);

    // Pie chart
    new Chart(document.getElementById("chartjs-dashboard-pie"), {
        type: "pie",
        data: {
            labels: itemTypes,
            datasets: [{
                data: counts,
                backgroundColor: [
                    "#4e73df", // blue
                    "#f6c23e", // yellow
                    "#e74a3b", // red
                    "#36b9cc", // teal
                    "#858796"  // gray
                ],
                borderWidth: 5
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: true,
                    position: 'bottom'
                }
            }
        }
    });
});
</script>
<script>
document.addEventListener("DOMContentLoaded", function() {
    // Demo data: categories with product counts
    const brandWiseArea = document.querySelector('.brand-wise-area');
    var brandProductCounts = <?php echo json_encode($proucts_count_by_brands, 15, 512) ?>;
    if (brandProductCounts.length > 0)brandWiseArea.classList.remove('d-none');
    // Prepare arrays for chart
    let brands = brandProductCounts.map(item => item.name);
    let counts = brandProductCounts.map(item => item.products_count);

    // Pie chart
    new Chart(document.getElementById("chartjs-dashboard-pie-second"), {
        type: "pie",
        data: {
            labels: brands,
            datasets: [{
                data: counts,
                backgroundColor: [
                    "#F25912", // teal
                    "#5C3E94", // blue
                    "#412B6B", // yellow
                    "#211832", // red
                    "#858796"  // gray
                ],
                borderWidth: 5
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: true,
                    position: 'bottom'
                }
            }
        }
    });
});
</script>
<script>
document.addEventListener("DOMContentLoaded", function() {
    // Demo data: categories with product counts
    const categoryWiseArea = document.querySelector('.category-wise-area');
    var categoryProductCounts = <?php echo json_encode($proucts_count_by_categories, 15, 512) ?>;
    if (categoryProductCounts.length > 0)categoryWiseArea.classList.remove('d-none');
    // Prepare arrays for chart
    let categories = categoryProductCounts.map(item => item.name);
    let counts = categoryProductCounts.map(item => item.products_count);

    // Pie chart
    new Chart(document.getElementById("chartjs-dashboard-pie-three"), {
        type: "pie",
        data: {
            labels: categories,
            datasets: [{
                data: counts,
                backgroundColor: [
                    "#F7374F", // blue
                    "#88304E", // yellow
                    "#e74a3b", // red
                    "#4FB7B3", // teal
                    "#739EC9"  // gray
                ],
                borderWidth: 5
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: true,
                    position: 'bottom'
                }
            }
        }
    });
});
</script>
<script>
document.addEventListener("DOMContentLoaded", function() {
    // Demo data: categories with product counts
    const subCategoryWiseArea = document.querySelector('.sub-category-wise-area');
    var subCategoryProductCounts = <?php echo json_encode($proucts_count_by_sub_categories, 15, 512) ?>;
    if (subCategoryProductCounts.length > 0)subCategoryWiseArea.classList.remove('d-none');
    // Prepare arrays for chart
    let subCategories = subCategoryProductCounts.map(item => item.name);
    let counts = subCategoryProductCounts.map(item => item.products_count);

    // Pie chart
    new Chart(document.getElementById("chartjs-dashboard-pie-four"), {
        type: "pie",
        data: {
            labels: subCategories,
            datasets: [{
                data: counts,
                backgroundColor: [
                    "#3B38A0", // blue
                    "#B2B0E8", // yellow
                    "#67C090", // red
                    "#26667F", // teal
                    "#858796"  // gray
                ],
                borderWidth: 5
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: true,
                    position: 'bottom'
                }
            }
        }
    });
});
</script><?php /**PATH D:\programming\laravel\achiya-varieties-shop-inventory-system-new-add-retail-price\resources\views/components/admin/reports/scripts.blade.php ENDPATH**/ ?>