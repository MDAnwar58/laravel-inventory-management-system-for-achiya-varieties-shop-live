<footer class="footer">
  <div class="container-fluid">
    <div class="row text-muted">
      <div class="col-12 d-flex justify-content-center align-items-center">
        <p class="mb-0 text-center">
          <div class="text-muted"><strong>&copy;Enjoy your business with smart management system</strong></div>
        </p>
      </div>
    </div>
  </div>
</footer>
<?php /**PATH D:\programming\laravel\achiya-varieties-shop-inventory-system-new-add-retail-price\resources\views/components/admin/footer.blade.php ENDPATH**/ ?>