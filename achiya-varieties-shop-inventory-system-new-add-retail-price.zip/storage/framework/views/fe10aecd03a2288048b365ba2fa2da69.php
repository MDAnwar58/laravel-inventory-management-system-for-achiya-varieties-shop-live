<script>
const tooltipTriggerList = document.querySelectorAll('[data-bs-toggle="tooltip"]')
const tooltipList = [...tooltipTriggerList].map(tooltipTriggerEl => new bootstrap.Tooltip(tooltipTriggerEl))
</script><?php /**PATH D:\programming\laravel\achiya-varieties-shop-inventory-system-new-add-retail-price\resources\views/components/admin/tool-tip.blade.php ENDPATH**/ ?>