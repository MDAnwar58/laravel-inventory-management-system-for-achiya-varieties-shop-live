<nav class="navbar navbar-expand navbar-light navbar-bg">
    <a class="sidebar-toggle js-sidebar-toggle">
        <i class="hamburger align-self-center"></i>
    </a>

    <div class="navbar-collapse collapse">
        <ul class="navbar-nav navbar-align">
            <li class="nav-item dropdown">
                <a class="nav-icon dropdown-toggle" href="#" id="alertsDropdown" data-bs-toggle="dropdown">
                    <div class="position-relative">
                        <i class="align-middle" data-feather="bell"></i>
                        <span class="indicator">
                            <?php
                            $count = 0;
                            if ($low_stock && $low_stock['products_count']) {
                            $count = $low_stock['products_count'];
                            }
                            ?>
                            <?php echo e($count); ?>

                        </span>
                    </div>
                </a>
                <div class="dropdown-menu dropdown-menu-lg dropdown-menu-end py-0" aria-labelledby="alertsDropdown">
                    <div class="dropdown-menu-header"><?php echo e($count); ?> Notifications</div>

                    <div class="list-group">
                        
                        <?php if($low_stock && $low_stock['products_count']): ?>
                        <a href="<?php echo e(route('admin.products', ['sf' => 'low stock'])); ?>" class="list-group-item">
                            <div class="row g-0 align-items-center">
                                <div class="col-2">
                                    <i class="text-warning" data-feather="bell"></i>
                                </div>
                                <div class="col-10">
                                    <div class="text-dark"><?php echo e($low_stock['products_count']); ?> Products Stock is Low</div>
                                    <div class="text-muted small mt-1"><?php echo e($low_stock['date_and_time']->diffForHumans()); ?></div>
                                </div>
                            </div>
                        </a>
                        <?php else: ?>
                        <a class="list-group-item pb-3">
                            <div class="text-muted small mt-1 text-center fs-5">notification not found</div>
                        </a>
                        <?php endif; ?>

                        
                    </div>
                    
                </div>
            </li>
            
            <li class="nav-item dropdown">
                <a class="nav-icon dropdown-toggle d-inline-block d-sm-none" href="#" data-bs-toggle="dropdown"><i class="align-middle" data-feather="settings"></i></a>

                <a class="nav-link dropdown-toggle d-none d-sm-inline-block" href="#" data-bs-toggle="dropdown">
                    <?php if(auth()->user()->avatar): ?>
                    <img src="<?php echo e(auth()->user()->avatar); ?>" class="avatar img-fluid rounded-circle me-1" alt="Avatar" />
                    <?php else: ?>
                    <img src="<?php echo e(asset('assets/img/avatars/user.png')); ?>" class="avatar img-fluid rounded-circle me-1" alt="Avatar" />
                    <?php endif; ?>
                    <span class="text-dark"><?php echo e(auth()->user()->name ?? "Auth User"); ?></span></a>
                <div class="dropdown-menu dropdown-menu-end">
                    <a class="dropdown-item" href="<?php echo e(route('admin.profile')); ?>"><i class="align-middle me-1" data-feather="user"></i> Profile</a>
                    
                    <a class="dropdown-item" href="<?php echo e(route('admin.settings')); ?>"><i class="align-middle me-1" data-feather="settings"></i> Settings</a>
                   
                    <a class="dropdown-item" href="#">
                     <i class="fa-solid fa-screwdriver-wrench me-1"></i> How to Controls
                    </a>
                    
                    <div class="dropdown-divider"></div>
                    <form action="<?php echo e(route('sign.out')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="dropdown-item">Log out</button>
                    </form>
                </div>
            </li>
        </ul>
    </div>
</nav>
<?php /**PATH D:\programming\laravel\achiya-varieties-shop-inventory-system-new-add-retail-price\resources\views/components/admin/navbar.blade.php ENDPATH**/ ?>