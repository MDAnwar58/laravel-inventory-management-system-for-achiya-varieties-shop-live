<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'landing_page' => null
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'landing_page' => null
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<section class="hero d-flex align-items-center">
    <div class="floating-shapes">
        <div class="shape"></div>
        <div class="shape"></div>
        <div class="shape"></div>
    </div>
    <div class="container hero-content">
        <div class="row align-items-center">
            <div class="col-lg-6 hero-content-area" data-aos="fade-right">
                <h1 class="text-white"><?php echo e($landing_page?->hero_title_part_1 ?? 'Smart Inventory'); ?> <span class="text-warning"><?php echo e($landing_page->hero_title_part_2 ?? 'Revolution'); ?></span></h1>
                <p class="text-white-50"><?php echo e($landing_page->short_des ?? 'Transform your business with inventory management. Real-time tracking, predictive analytics, and automated optimization all in one powerful platform.'); ?></p>
                <div class="d-flex gap-3 flex-wrap">
                    <a href="<?php echo e(route('admin.dashboard')); ?>" class="btn btn-gradient btn-lg text-uppercase cta-button">
                        <i class="fas fa-rocket me-2"></i>Get Start
                    </a>
                </div>
                
            </div>
            <div class="col-lg-6 hero-dashboard mt-lg-0 mt-5">
                <div class="dashboard-preview glass">
                    <div class="dashboard-mockup">
                        <div class="mockup-header">
                            <div class="mockup-dot dot-red"></div>
                            <div class="mockup-dot dot-yellow"></div>
                            <div class="mockup-dot dot-green"></div>
                        </div>
                        <div class="mockup-content">
                            <div class="chart-bar bar-1"></div>
                            <div class="chart-bar bar-2"></div>
                            <div class="chart-bar bar-3"></div>
                            <div class="chart-bar bar-4"></div>
                            <div class="position-absolute top-50 start-50 translate-middle">
                                <i class="fas fa-chart-line fa-3x" style="color: #667eea; opacity: 0.3;"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


<?php /**PATH D:\programming\laravel\achiya-varieties-shop-inventory-system-new-add-retail-price\resources\views/components/userend/hero-section.blade.php ENDPATH**/ ?>