<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'breadcrumbs' => [],
    'create_btn_name' => null,
    'btn_route' => null,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'breadcrumbs' => [],
    'create_btn_name' => null,
    'btn_route' => null,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<?php if(!empty($breadcrumbs)): ?>
  <div class="d-flex justify-content-between align-items-start pb-1">
    <nav
      style="--bs-breadcrumb-divider: url(&#34;data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='8' height='8'%3E%3Cpath d='M2.5 0L1 1.5 3.5 4 1 6.5 2.5 8l4-4-4-4z' fill='%236c757d'/%3E%3C/svg%3E&#34;);"
      aria-label="breadcrumb">
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="<?php echo e(route('admin.dashboard')); ?>" class="d-flex align-items-center gap-1 text-dark"><i
              class="align-middle" data-feather="sliders" style="width: 13px; height: 13px;"></i>
            <span>Dashboard</span></a>
        </li>
        <?php if(count($breadcrumbs) > 0): ?>
          <?php $__currentLoopData = $breadcrumbs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $breadcrumb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($breadcrumb['route']): ?>
              <li class="breadcrumb-item">
                <a href="<?php echo e(route($breadcrumb['route'])); ?>" class="d-flex align-items-center gap-1 text-dark">
                  <?php if($breadcrumb['icon']): ?>
                    <i class="align-middle" data-feather="<?php echo e($breadcrumb['icon']); ?>" style="width: 13px; height: 13px;"></i>
                  <?php endif; ?>
                  <span><?php echo e($breadcrumb['name']); ?></span>
                </a>
              </li>
            <?php else: ?>
              <li class="breadcrumb-item active" aria-current="page"><?php echo e($breadcrumb['name']); ?></li>
            <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
      </ol>
    </nav>
    <?php if($create_btn_name): ?>
      <a href="<?php echo e(route($btn_route)); ?>" class="btn btn-info"><?php echo e($create_btn_name); ?></a>
    <?php endif; ?>
  </div>
<?php endif; ?>
<?php /**PATH D:\programming\laravel\achiya-varieties-shop-inventory-system-new-add-retail-price\resources\views/components/admin/breadcrumb.blade.php ENDPATH**/ ?>