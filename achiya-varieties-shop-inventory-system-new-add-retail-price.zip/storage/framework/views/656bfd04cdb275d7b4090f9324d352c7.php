<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
'total_products_count' => 00,
'total_products_value' => 0.00,
'total_low_stock_products_count' => 00,
'total_profits' => 0.00,
'total_low_stock_products' => [],
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
'total_products_count' => 00,
'total_products_value' => 0.00,
'total_low_stock_products_count' => 00,
'total_profits' => 0.00,
'total_low_stock_products' => [],
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<div class="px-3">
    <div class="inventory-title d-flex justify-content-between align-items-center pb-2">
        <h5 class="fs-3 fw-semibold text-secondary">Inventory Reports</h5>
        <form action="<?php echo e(route('admin.inventory.reports.export')); ?>" method="GET">
            <button type="submit" class="btn btn-sm btn-info pb-1 pt-2 rounded-3" data-bs-toggle="tooltip" data-bs-title="Export To Excel"><i class="fa-solid fa-file-arrow-down fs-4"></i></button>
        </form>
    </div>
    <div class="inventory-report-area">
        <div class="row pt-1">
            <div class="col-xxl-3 col-xl-4 col-sm-6">
                <div class="card">
                    <div class="card-body total-cards-body px-5 w-100 px-5 w-100 text-center">
                        <div class="text-center">
                            <h3 class="fw-bold fs-3 text-muted text-uppercase">Total Products</h3>
                            <p class="fw-bold fs-3 text-secondary-emphasis"><?php echo e($total_products_count); ?></p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xxl-3 col-xl-4 col-sm-6">
                <div class="card">
                    <div class="card-body total-cards-body px-5 w-100 px-5 w-100 text-center">
                        <div class="text-center">
                            <h3 class="fw-bold fs-3 text-muted text-uppercase">Total Values Of Products</h3>
                            <p class="fw-bold fs-3 text-secondary-emphasis"><span class="bdt">৳</span><span><?php echo e($total_products_value); ?></span></p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xxl-3 col-xl-4 col-sm-6">
                <div class="card">
                    <div class="card-body total-cards-body px-5 w-100 px-5 w-100 text-center">
                        <div class="text-center">
                            <h3 class="fw-bold fs-3 text-muted text-uppercase">Low Stock Products</h3>
                            <p class="fw-bold fs-3 text-secondary-emphasis"><?php echo e($total_low_stock_products_count); ?></p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xxl-3 col-xl-4 col-sm-6">
                <div class="card">
                    <div class="card-body total-cards-body px-5 w-100 px-5 w-100 text-center">
                        <div class="text-center">
                            <h3 class="fw-bold fs-3 text-muted text-uppercase">Total Profits</h3>
                            <p class="fw-bold fs-3 text-secondary-emphasis"><span class="bdt">৳</span><?php echo e($total_profits); ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6 item-type-wise-area d-none">
                <div class="card">
                    <div class="card-body w-100">
                        <h4 class="text-center fs-bold text-uppercase text-muted pb-1">Item Type Wise Products</h4>
                        <div class="chart chart-xs">
                            <canvas id="chartjs-dashboard-pie"></canvas>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6 brand-wise-area d-none">
                <div class="card">
                    <div class="card-body w-100">
                    <h4 class="text-center fs-bold text-uppercase text-muted pb-1">Brand Wise Products</h4>
                        <div class="chart chart-xs">
                            <canvas id="chartjs-dashboard-pie-second"></canvas>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6 category-wise-area d-none">
                <div class="card">
                    <div class="card-body w-100">
                    <h4 class="text-center fs-bold text-uppercase text-muted pb-1">Category Wise Products</h4>
                        <div class="chart chart-xs">
                            <canvas id="chartjs-dashboard-pie-three"></canvas>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6 sub-category-wise-area d-none">
                <div class="card">
                    <div class="card-body w-100">
                    <h4 class="text-center fs-bold text-uppercase text-muted pb-1">Sub Category Wise Products</h4>
                        <div class="chart chart-xs">
                            <canvas id="chartjs-dashboard-pie-four"></canvas>
                        </div>
                    </div>
                </div>
            </div>
            <div id="inventory-table-area" class="col-md-12">
                <div class="card">
                    <div class="card-header pb-0 mb-0">
                        <div class="card-title pb-0 mb-0">Low Stock Products</div>
                    </div>
                    <div class="card-body pt-0 w-100">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Product</th>
                                        <th>Item Type</th>
                                        <th>Brand</th>
                                        <th>Category</th>
                                        <th>Sub Category</th>
                                        <th>Current Stock</th>
                                        <th>Price</th>
                                        <th>Retial Price</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php
                                        function formatNumber($num, $type = '')
                                        {
                                            $n = (float) $num;
                                            if ($type === 'ft' || $type === 'yard' || $type === 'm') { 
                                                if ($n < 1)$repl = (string) intval(round($n * 1000 / 10));
                                                else $repl = rtrim(rtrim(number_format($n, 2, '.', ''), '0'), '.');
                                                return $repl;
                                            } else {
                                                if ($n < 1) {
                                                    return preg_replace('/\.0+$/', '', (string) ($n * 1000));
                                                }

                                                // strip trailing .000 etc. after 3-decimal rounding
                                                return rtrim(rtrim(number_format($n, 3, '.', ''), '0'), '.');
                                            }
                                        }
                                        function kg_or_gm_or_ft_yard_or_m($num, $type = 'kg')
                                        {
                                            if ($type === 'kg') {
                                                $n = (float) $num;
                                                return $n < 1 ? 'gm' : 'kg';
                                            } elseif ($type === 'ft') {
                                                $n = (float) $num;
                                                return $n < 1 ? 'inchi' : 'ft';
                                            } elseif ($type === 'yard') {
                                                $n = (float) $num;
                                                return $n < 1 ? 'inchi' : 'yard';
                                            } else {
                                                $n = (float) $num;
                                                return $n < 1 ? 'inchi' : 'm';
                                            }
                                        }
                                    ?>

                                    <?php if(count($total_low_stock_products) > 0): ?>
                                    <?php $__currentLoopData = $total_low_stock_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $stock = $product->stock_w_type !== 'none' ? formatNumber($product->stock_w, $product->stock_w_type).kg_or_gm_or_ft_yard_or_m($product->stock_w, $product->stock_w_type) : ((int)$product->stock_w)." pcs";
                                    ?>
                                    <tr>
                                        <td>
                                            <div class="d-flex align-items-center gap-1">
                                                <?php if($product->image): ?>
                                                    <img src="<?php echo e($product->image); ?>" alt="<?php echo e($product->name); ?>" class="rounded-circle" style="width: 30px;height: 30px;">
                                                <?php else: ?>
                                                    <div class="border shadow rounded-3 d-flex justify-content-center align-items-center" style="width: 30px; height: 30px;"><i class="fa-solid fa-image text-secondary-emphasis fs-5"></i></div>
                                                <?php endif; ?>
                                                <span class="fw-bold"><?php echo e($product->name); ?></span>
                                            </div>
                                        </td>
                                        <td><?php echo e($product->item_type?->name ?? 'N/A'); ?></td>
                                        <td><?php echo e($product->brand?->name ?? 'N/A'); ?></td>
                                        <td><?php echo e($product->category?->name ?? 'N/A'); ?></td>
                                        <td><?php echo e($product->sub_category?->name ?? 'N/A'); ?></td>
                                        <td><?php echo e($stock); ?></td>
                                        <td>
                                            <div class=" text-dark"><span class="bdt">৳</span><?php echo e($product->price); ?></div>
                                        </td>
                                        <td>
                                            <div class=" text-dark">
                                                <?php if($product->retail_price): ?>
                                                <span class="bdt">৳</span><?php echo e($product->retail_price); ?>

                                                <?php else: ?>
                                                <span class="text-muted">N/A</span>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\programming\laravel\achiya-varieties-shop-inventory-system-new-add-retail-price\resources\views/components/admin/reports/inventory-reports.blade.php ENDPATH**/ ?>