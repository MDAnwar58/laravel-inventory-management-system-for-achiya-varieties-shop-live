<div class="col-xxl-7 col-xl-8 col-md-7 col-sm-12 ">
    <div class="card flex-fill w-100">
        <div class="card-header">
            <h5 class="card-title mb-0">Monthly Sales Earnings</h5>
        </div>
        <div class="card-body py-3">
            <div class="chart chart-sm">
                <canvas id="chartjs-dashboard-line"></canvas>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\programming\laravel\achiya-varieties-shop-inventory-system-new-add-retail-price\resources\views/components/admin/dashboard/monthly-sales.blade.php ENDPATH**/ ?>