<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
'salesTop5ProductsCount' => []
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
'salesTop5ProductsCount' => []
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<div class="col-12 d-flex order-2">
    <div class="w-100">
        <div class="card flex-fill w-100">
            <div class="card-header">
                <h5 class="card-title mb-0">Top 5 Selling Products</h5>
            </div>
            <div class="card-body d-flex" style="margin-top: -2rem;">
                <div class="align-self-center w-100">
                    <div class="row">
                        <div class="col-md-7">
                            <div class="py-3">
                                <div class="chart chart-xs">
                                    <canvas id="chartjs-dashboard-pie"></canvas>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-5">
                            <table class="table mb-0">
                                <tbody>
                                    <?php if(count($salesTop5ProductsCount) > 0): ?>
                                        <?php
                                            function formatNumber($num)
                                            {
                                                $n = (float) $num;
                                                if ($n < 1) {
                                                    return preg_replace('/\.0+$/', '', (string) ($n * 1000));
                                                }

                                                // strip trailing .000 etc. after 3-decimal rounding
                                                return rtrim(rtrim(number_format($n, 3, '.', ''), '0'), '.');
                                            }
                                            function kg_or_gm_or_ft($num, $type = 'kg')
                                            {
                                                if ($type === 'kg') {
                                                    $n = (float) $num;
                                                    return $n < 1 ? 'gm' : 'kg';
                                                } else {
                                                    $n = (float) $num;
                                                    return $n < 1 ? 'inchi' : 'ft';
                                                }
                                            }
                                        ?>
                                        <?php $__currentLoopData = $salesTop5ProductsCount; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($product['name']); ?></td>
                                            <?php if($product['stock_w_type'] == 'none'): ?>
                                                <td class="text-end"><?php echo e(formatNumber($product['total_qty'])); ?> pcs</td>
                                            <?php else: ?>
                                                <td class="text-end"><?php echo e(formatNumber($product['total_qty'])); ?> <?php echo e(kg_or_gm_or_ft($product['total_qty'], $product['stock_w_type'])); ?></td>
                                            <?php endif; ?>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>

                    
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\programming\laravel\achiya-varieties-shop-inventory-system-new-add-retail-price\resources\views/components/admin/dashboard/top-5-products-sales-count.blade.php ENDPATH**/ ?>