<div class="d-flex text-center ps-3">
    <a class="auth-logo text-decoration-none" href="<?php echo e(route('welcome')); ?>">
        <img src="<?php echo e(asset('favicon_io2/android-chrome-512x512.png')); ?>" style="width: 50px;" alt="logo">
        <div>
            আছিয়া
            <div style="font-size: 12px; margin-top: -0.55rem;">ভ‍্যারাইটিস শপ</div>
        </div>
    </a>
</div>
<?php /**PATH D:\programming\laravel\achiya-varieties-shop-inventory-system-new-add-retail-price\resources\views/components/admin/logo.blade.php ENDPATH**/ ?>