<footer id="contact" class="footer">
    <div class="container pt-0">
        <div class="row align-items-center">
            <div class="col-md-6 text-md-start text-center">
                <p class="mb-0 text-whtie">&copy; 2024 SmartStock Pro. All rights reserved.</p>
            <p class="mb-0 small">Developed by MD. Anwar Sayeed | Contact: +880 1918725999</p>
            </div>
            <div class="col-md-6 text-md-end text-center pt-md-0 pt-3">
                <p class="mb-0 text-whtie">Made with <i class="fas fa-heart text-danger"></i> for businesses worldwide</p>
            </div>
        </div>
    </div>
</footer>
<?php /**PATH D:\programming\laravel\achiya-varieties-shop-inventory-system-new-add-retail-price\resources\views/components/userend/footer.blade.php ENDPATH**/ ?>