<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta property="og:type" content="website" />
    <meta property="og:title" content="আছিয়া ভ্যারাইটিস শপ" />
    <meta name="author" content="আছিয়া ভ‍্যারাইটিস শপ" />
    <meta name="description" content="সকল প্রকার হার্ডওয়ার ও স্যানিটারি সামগ্রী পাইকারি ও খুচরা বিক্রয়ের বিশেষ প্রতিষ্ঠান। কমির সপিং মার্কেট, কলারোয়া, সাতক্ষীরা।" />
    <meta name="keywords" content="আছিয়া ভ‍্যারাইটিস শপ Login, আছিয়া ভ‍্যারাইটিস শপ Sing In, আছিয়া ভ‍্যারাইটিস শপ Sign Up, আছিয়া ভ‍্যারাইটিস শপ, Achiya Varieties Shop, Achiya Varieties Shop Login, Achiya Varieties Shop Sign In, Achiya Varieties Shop Sign Up" />
    <meta property="og:url" content="https://achiya-varieties.shop" />

    <title>আছিয়া ভ‍্যারাইটিস শপ</title>
    <?php if (isset($component)) { $__componentOriginal1e8a58c8fbf84d3400c6786b34dea413 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1e8a58c8fbf84d3400c6786b34dea413 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.userend.bootstrap-min-css','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('userend.bootstrap-min-css'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1e8a58c8fbf84d3400c6786b34dea413)): ?>
<?php $attributes = $__attributesOriginal1e8a58c8fbf84d3400c6786b34dea413; ?>
<?php unset($__attributesOriginal1e8a58c8fbf84d3400c6786b34dea413); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1e8a58c8fbf84d3400c6786b34dea413)): ?>
<?php $component = $__componentOriginal1e8a58c8fbf84d3400c6786b34dea413; ?>
<?php unset($__componentOriginal1e8a58c8fbf84d3400c6786b34dea413); ?>
<?php endif; ?>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <?php if (isset($component)) { $__componentOriginal3d4ad94aa2d3c0a6be4ea967d494bfe2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3d4ad94aa2d3c0a6be4ea967d494bfe2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.userend.styles','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('userend.styles'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3d4ad94aa2d3c0a6be4ea967d494bfe2)): ?>
<?php $attributes = $__attributesOriginal3d4ad94aa2d3c0a6be4ea967d494bfe2; ?>
<?php unset($__attributesOriginal3d4ad94aa2d3c0a6be4ea967d494bfe2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3d4ad94aa2d3c0a6be4ea967d494bfe2)): ?>
<?php $component = $__componentOriginal3d4ad94aa2d3c0a6be4ea967d494bfe2; ?>
<?php unset($__componentOriginal3d4ad94aa2d3c0a6be4ea967d494bfe2); ?>
<?php endif; ?>
</head>
<body>
    <?php if (isset($component)) { $__componentOriginalba447f10b04822c0b118b3e7c0c559b2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalba447f10b04822c0b118b3e7c0c559b2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.userend.navbar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('userend.navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalba447f10b04822c0b118b3e7c0c559b2)): ?>
<?php $attributes = $__attributesOriginalba447f10b04822c0b118b3e7c0c559b2; ?>
<?php unset($__attributesOriginalba447f10b04822c0b118b3e7c0c559b2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalba447f10b04822c0b118b3e7c0c559b2)): ?>
<?php $component = $__componentOriginalba447f10b04822c0b118b3e7c0c559b2; ?>
<?php unset($__componentOriginalba447f10b04822c0b118b3e7c0c559b2); ?>
<?php endif; ?>

    <?php echo $__env->yieldContent('content'); ?>

    <?php if (isset($component)) { $__componentOriginalf2c6990390f2aace9768a1b52f283fc3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf2c6990390f2aace9768a1b52f283fc3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.userend.footer','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('userend.footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf2c6990390f2aace9768a1b52f283fc3)): ?>
<?php $attributes = $__attributesOriginalf2c6990390f2aace9768a1b52f283fc3; ?>
<?php unset($__attributesOriginalf2c6990390f2aace9768a1b52f283fc3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf2c6990390f2aace9768a1b52f283fc3)): ?>
<?php $component = $__componentOriginalf2c6990390f2aace9768a1b52f283fc3; ?>
<?php unset($__componentOriginalf2c6990390f2aace9768a1b52f283fc3); ?>
<?php endif; ?>


    
    <?php if (isset($component)) { $__componentOriginale00656d8514c1fb76a87a24342a73fb3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale00656d8514c1fb76a87a24342a73fb3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.userend.bootstrap-min-js','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('userend.bootstrap-min-js'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale00656d8514c1fb76a87a24342a73fb3)): ?>
<?php $attributes = $__attributesOriginale00656d8514c1fb76a87a24342a73fb3; ?>
<?php unset($__attributesOriginale00656d8514c1fb76a87a24342a73fb3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale00656d8514c1fb76a87a24342a73fb3)): ?>
<?php $component = $__componentOriginale00656d8514c1fb76a87a24342a73fb3; ?>
<?php unset($__componentOriginale00656d8514c1fb76a87a24342a73fb3); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal15102bd7e09417efd6a7f521611207d8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal15102bd7e09417efd6a7f521611207d8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.userend.chart-js','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('userend.chart-js'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal15102bd7e09417efd6a7f521611207d8)): ?>
<?php $attributes = $__attributesOriginal15102bd7e09417efd6a7f521611207d8; ?>
<?php unset($__attributesOriginal15102bd7e09417efd6a7f521611207d8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal15102bd7e09417efd6a7f521611207d8)): ?>
<?php $component = $__componentOriginal15102bd7e09417efd6a7f521611207d8; ?>
<?php unset($__componentOriginal15102bd7e09417efd6a7f521611207d8); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal8e28d8541f541bef68e2b5cb766edf62 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8e28d8541f541bef68e2b5cb766edf62 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.userend.scripts','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('userend.scripts'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8e28d8541f541bef68e2b5cb766edf62)): ?>
<?php $attributes = $__attributesOriginal8e28d8541f541bef68e2b5cb766edf62; ?>
<?php unset($__attributesOriginal8e28d8541f541bef68e2b5cb766edf62); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e28d8541f541bef68e2b5cb766edf62)): ?>
<?php $component = $__componentOriginal8e28d8541f541bef68e2b5cb766edf62; ?>
<?php unset($__componentOriginal8e28d8541f541bef68e2b5cb766edf62); ?>
<?php endif; ?>
</body>
</html>
<?php /**PATH D:\programming\laravel\achiya-varieties-shop-inventory-system-new-add-retail-price\resources\views/layouts/app.blade.php ENDPATH**/ ?>