<div id="loaderLoadingOverlay" class="LoadingOverlay">
  <div id="linePreloader" class="linePreloader"></div>
</div>
<?php $__env->startPush('style'); ?>
  <style>
    .LoadingOverlay {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      z-index: 9999;
      /* overlay layer */
      background-color: rgba(255, 255, 255, 0.3);
      cursor: auto;
    }

    .linePreloader {
      position: fixed;
      /* stays at viewport top */
      top: 0 !important;
      left: 0;
      bottom: auto !important;
      right: auto !important;
      margin: 0 !important;
      width: 100%;
      height: 3px;
      background: linear-gradient(to right, rgb(68, 120, 180), #3b7ddd);
      background-size: 25% !important;
      background-repeat: repeat-y !important;
      border-radius: 4px;
      background-position: -25% 0;
      animation: scroll 1.2s ease-in-out infinite;
      z-index: 10000;
      /* above overlay */
    }

    @keyframes scroll {
      50% {
        background-size: 80%;
      }

      100% {
        background-position: 125% 0;
      }
    }
  </style>
<?php $__env->stopPush(); ?><?php /**PATH D:\programming\laravel\achiya-varieties-shop-inventory-system-new-add-retail-price\resources\views/components/admin/preloader.blade.php ENDPATH**/ ?>