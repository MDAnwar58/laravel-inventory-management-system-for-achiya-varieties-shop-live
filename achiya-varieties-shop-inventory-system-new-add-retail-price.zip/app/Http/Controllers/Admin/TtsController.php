<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class TtsController extends Controller
{
    public function generate()
    {
        return true;
    }
}
